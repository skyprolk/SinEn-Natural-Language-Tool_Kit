from os.path import dirname, abspath, join

PROJECT_PATH = join(dirname(abspath(__file__)), '..')

RESOURCE_PATH = join(PROJECT_PATH, 'sinling', 'resources')
