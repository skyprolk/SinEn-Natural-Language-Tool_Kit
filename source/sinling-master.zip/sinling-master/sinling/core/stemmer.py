__all__ = [
    'Stemmer'
]


class Stemmer:
    def __init__(self):
        pass

    def stem(self, text):
        raise NotImplementedError
