from sinling.sinhala import *
